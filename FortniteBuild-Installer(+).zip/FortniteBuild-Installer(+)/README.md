# ☞ Fortnite Build-Installer(+) 
More builds and Languages added by: **Ducki67** ✅
ℹ️ *NOTE:* ‼️ I do NOT own this i, just made a "better" sort of version of the Installer that uses [FnBuilds github ](https://github.com/n6617x/Fortnitebuilds) and [GalaxiaFN website ](https://galaxiafn.co.uk) . ✅
Also all links to the Githubs, Websites, Discord servers,  are available in the Allpication too. ✅

*Original CODE credits to:* **By Waslyl** 
*Original REPO credits to:* **Shoqapique**


**☞ Features Build-Installer(+)**

🔳 - All downloadable Builds:*(starting from **OT6.5** up to **20.40** )*.

🔳 - More Languages.

🔳 - Credits and Information in the Application.

**☞ TO DO**

🔲 - "Website online" check.

🔲 - Auto extractor for both RAR and ZIP files.

🔲 - Add "Asian" languages (If needed)

# REALESES *Build-Installer(+)*
⚠️ Coming soon. ⚠️



# ☞ Fortnite Build Installer 📌 (original)
This program was made to aim Fortnite OG Community that want to download OG Fortnite Builds.
**You will be able to download more easily and faster your *favorite builds* !**
This Program was made **By Waslyl**


# ☞ IMPORTANT
!!! The code was made **By Waslyl** and the repo of the build was made and hosted by **Shoqapique**
https://github.com/Shoqaratio/fortnite-build

## ☞ REQUIREMENTS
- [Visual Studio](https://visualstudio.microsoft.com/fr/thank-you-downloading-visual-studio/?sku=Community&channel=Release&version=VS2022&source=VSLandingPage&cid=2030&passive=false) (Have basic knowledge to run an app (really difficult for some people))

## ☞ INSTALLATION 🗂

1. Download the Project
2. Replace **debug** to **release** and **Any CPU** to **x64**
3. Launch the program
5. Open the application and follow the instructions | the application is located in (\bin\Release\net8.0)

***If you need help with the FortniteBuildInstaller, you can contact with Wasly via [GalaxiaFN Discord](https://dsc.gg/galaxiaftn) or [Fortnite-Build Discord](https://discord.gg/QkfTM4gY9d)*** (*These discord link are available in the Build-Installer Allpication too.*).

**All right are deserved by Waslyl and Shoqapique**, you can use it for your own purpose but please *credit:* **By Waslyl** and **Shoqapique** 😁
There's 🧾***MIT license***🧾 too, don't try to skid ☺️

